#include <stdio.h>
#include <cs50.h>

int main(void)
{
    // Promt user or name
    string answer = get_string("What's your name? ");
    // Greet User by name
    printf("hello, %s\n", answer);
}